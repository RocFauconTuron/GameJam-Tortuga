local Actor = Actor or require "Scripts/actor"
local Car = Actor:extend()

function Car:new(x,y)

end

function Car:update(dt)
    
end

function Car:draw()
    
end


return Car