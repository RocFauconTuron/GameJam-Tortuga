Tasca A2: Moviment d'sprites amb Love2d

A partir del esquema que es proposa, s'hauran d'implementar les classes Asteroid i Ship per a que tant la nau com els asteroides tinguin un moviment semblant al que es veu al vídeo.

Les classes Object, Vector i Actor no calen modificacions.

Important: Cal que escriviu comentaris al codi nou indicant quin és l'objectiu del codi.

E1: Moviment de la nau [ 35 punts]
La nau farà servir les fletxes esquerra i dreta per rotar sobre si mateixa, i les fletxes amunt i avall per accelerar o frenar.

E2: Moviment d'un asteroide [ 30 punts]
Els asteroides giren sobre si mateixos al mateix temps que es mouen, crea una variable rSpeed per determinar la rotació sobre si mateix.

Si un asteroide surt de la pantalla, cal que aparegui en una altra posició al atzar.

E3: Nous asteroides [ 35 punts]

Per una banda prement la tecla "a" es fan aparèixer nous asteroides, i aquests han d'aparèixer a la pantalla col·locats de forma aleatòria.

Per tant, la seva imatge, posició, angle i velocitat s'han de determinar al atzar.
