function love.conf(t)
  t.window.width = 800  
  t.window.height = 600
  t.console = true
  t.title = "Tasca A2: Moviment d'sprites amb Love2d"
end
